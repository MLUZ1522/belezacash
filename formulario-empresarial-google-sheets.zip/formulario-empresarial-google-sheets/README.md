# formulario-empresarial-google-sheets

Formulário de contato empresarial moderno (HTML + Tailwind) com validação e integração para **Google Sheets** via Google Apps Script.

## O que tem neste repositório
- `index.html` — página do formulário (Tailwind CDN).  
- `apps_script/Code.gs` — código para colar no editor do Google Apps Script (ligado à sua planilha).  
- `README.md` — este arquivo com instruções.  
- `LICENSE` — licença MIT.

## Instruções rápidas

### 1) Preparar a Planilha
1. Crie uma nova planilha no Google Sheets.  
2. Na primeira linha, adicione cabeçalhos (exemplo):
```
Data | Responsável | Telefone | CEP | Endereço | Bairro | Empresa | E-mail | TelEmpresa | Site | Instagram | TikTok | Facebook | RedeX | Descrição
```

### 2) Apps Script (backend)
1. Abra a planilha > **Extensões → Apps Script**.  
2. No editor, apague qualquer conteúdo e cole o conteúdo do arquivo `apps_script/Code.gs`.  
3. Salve.

### 3) Publicar como Web App
1. Clique em **Implantar → Novo Implantação → Tipo: Web app**.  
2. Defina:
   - **Executar como:** Você mesmo  
   - **Quem tem acesso:** Qualquer pessoa (mesmo anônima)  
3. Clique em **Implantar** e copie a URL gerada (algo como `https://script.google.com/macros/s/XXXX/exec`).

### 4) Configurar `index.html`
1. Abra `index.html` e substitua o valor da constante `WEBAPP_URL` pela URL do seu Web App.
2. Faça upload do `index.html` em qualquer hospedagem de site estático (Netlify, GitHub Pages, TiinyHost, Vercel, etc.) ou abra localmente para teste.

### 5) Observações sobre upload de imagens
Este template envia campos de texto diretamente para o Apps Script. Envio de arquivos (imagens) para o Google Drive requer um fluxo adicional:
- Faça um endpoint que receba os arquivos e grave no Drive (ex.: Apps Script com upload via base64).
- Salve os links dos arquivos na planilha.
Se quiser, eu posso adicionar esse fluxo para você.

## Hospedagem recomendada (gratuita)
- GitHub Pages — gratuito para sites estáticos.  
- Netlify — fácil deploy contínuo.  
- Vercel — ideal para projetos estáticos.  
- TiinyHost / static.run — para uploads rápidos.

## Licença
MIT © formulario-empresarial-google-sheets
